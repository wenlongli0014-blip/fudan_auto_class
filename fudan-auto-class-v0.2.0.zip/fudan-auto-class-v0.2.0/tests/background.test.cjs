const {test}=require('node:test');const assert=require('node:assert/strict');const vm=require('node:vm');const fs=require('node:fs');const path=require('node:path');
const Csource=fs.readFileSync(path.join(__dirname,'../extension/core.js'),'utf8');const Bsource=fs.readFileSync(path.join(__dirname,'../extension/background.js'),'utf8');
function setup(){
 let listener;const store={connection:{tabId:8,documentId:'doc-1'}};let current=null;const url='http://yjsxk.fudan.edu.cn/yjsxkapp/test';
 const ctx=vm.createContext({URL,Date,crypto:require('node:crypto').webcrypto,console,chrome:{
  storage:{session:{get:async key=>({[key]:structuredClone(store[key])}),set:async v=>Object.assign(store,structuredClone(v))}},
  action:{setBadgeText:async()=>{},setBadgeBackgroundColor:async()=>{}},
  scripting:{executeScript:async()=>[]},
  tabs:{get:async id=>({id,url}),sendMessage:async(id,m)=>{
   if(m.type==='CHECK')return {ok:true,checks:[]};
   if(m.type==='ARM_PAGE'){current={id:m.id,status:'armed',logs:[]};return {ok:true,snapshot:current};}
   if(m.type==='STATUS_PAGE')return {ok:true,snapshot:current};
   if(m.type==='STOP_PAGE'){if(current)current.status='stopped';return {ok:true};}
  },onRemoved:{addListener(){}}},
  runtime:{getURL:()=> 'chrome-extension://test/',onMessage:{addListener:fn=>listener=fn},onInstalled:{addListener(){}}}
 }});
 ctx.importScripts=()=>vm.runInContext(Csource,ctx);vm.runInContext(Bsource,ctx);
 const ui={url:'chrome-extension://test/popup.html'};
 const page={url,tab:{id:8},documentId:'doc-1'};
 const send=(m,s=ui)=>new Promise(r=>listener(m,s,r));
 const arm=()=>send({type:'ARM',tabId:8,documentId:'doc-1',config:{...ctx.FudanCore.defaults,startAt:Date.now()+1500,targets:[{category:'common',subcategory:'政治理论课',fullName:'高等统计2026202701MATH70001.01'}],mode:'live'}});
 return {send,arm,store,page,ctx,losePage:()=>current=null};
}
test('permission bound to exact tab, document and job',async()=>{
 const h=setup();assert.equal((await h.arm()).ok,true);h.store.job.config.startAt=Date.now()-1;const id=h.store.job.id;
 for(const sender of [{...h.page,documentId:'other'},{...h.page,tab:{id:9}},{...h.page,url:'https://evil.example/'}])assert.equal((await h.send({type:'PERMIT',id,kind:'select',target:'0'},sender)).ok,false);
 assert.equal((await h.send({type:'PERMIT',id,kind:'select',target:'0'},h.page)).ok,true);
 assert.equal((await h.send({type:'PERMIT',id,kind:'select',target:'0'},h.page)).ok,false);
});
test('stop is authoritative and late reports cannot restart job',async()=>{
 const h=setup();await h.arm();h.store.job.config.startAt=Date.now()-1;const id=h.store.job.id;
 await h.send({type:'STOP'});await h.send({type:'REPORT',snapshot:{id,status:'running'}},h.page);
 assert.equal(h.store.job.status,'stopped');assert.equal((await h.send({type:'PERMIT',id,kind:'select',target:'0'},h.page)).ok,false);
});
test('only one active job; missing page becomes paused',async()=>{
 const h=setup();await h.arm();assert.equal((await h.arm()).ok,false);h.losePage();const r=await h.send({type:'STATUS'});assert.equal(r.job.status,'paused');
});
test('cannot click before schedule, confirm before selection or after deadline',async()=>{
 const h=setup();await h.arm();const id=h.store.job.id;
 assert.equal((await h.send({type:'PERMIT',id,kind:'select',target:'0'},h.page)).ok,false);
 h.store.job.config.startAt=Date.now()-1;
 assert.equal((await h.send({type:'PERMIT',id,kind:'confirm',target:'0'},h.page)).ok,false);
 h.store.job.config.startAt=Date.now()-3600000;
 assert.equal((await h.send({type:'PERMIT',id,kind:'select',target:'0'},h.page)).ok,false);
});
test('concurrent duplicate permits produce exactly one authorization',async()=>{
 const h=setup();await h.arm();h.store.job.config.startAt=Date.now()-1;const id=h.store.job.id;
 const results=await Promise.all([1,2,3].map(()=>h.send({type:'PERMIT',id,kind:'select',target:'0'},h.page)));assert.equal(results.filter(r=>r.ok).length,1);
});

test('preview mode permits opening a dialog but forbids final confirmation',async()=>{
 const h=setup();await h.arm();h.store.job.config.startAt=Date.now()-1;h.store.job.config.mode='preview';const id=h.store.job.id;
 assert.equal((await h.send({type:'PERMIT',id,kind:'select',target:'0'},h.page)).ok,true);
 assert.equal((await h.send({type:'PERMIT',id,kind:'confirm',target:'0'},h.page)).ok,false);
});
test('dry mode refuses any selection authorization',async()=>{
 const h=setup();await h.arm();h.store.job.config.startAt=Date.now()-1;h.store.job.config.mode='dry';
 assert.equal((await h.send({type:'PERMIT',id:h.store.job.id,kind:'select',target:'0'},h.page)).ok,false);
});
