(() => {
  if(globalThis.FudanPage)return;
  const C=globalThis.FudanCore,A=globalThis.FudanAdapter;
  let job=null,timer=null,panel=null,generation=0,busy=false;
  const terminal=s=>['done','paused','stopped'].includes(s);
  function snapshot(){return job?{id:job.id,status:job.status,startAt:job.config.startAt,mode:job.config.mode,targets:job.targets,logs:job.logs,updatedAt:Date.now()}:null;}
  function draw(){
    if(!job)return;
    if(!panel){
      panel=document.createElement('div');panel.style.cssText='position:fixed;right:16px;bottom:16px;z-index:2147483647';
      const shadow=panel.attachShadow({mode:'closed'}),box=document.createElement('div'),status=document.createElement('div'),button=document.createElement('button');
      box.style.cssText='background:#102d40;color:white;padding:16px;border-radius:12px;font:14px system-ui;max-width:370px;box-shadow:0 8px 32px #0004';status.style.whiteSpace='pre-wrap';button.textContent='立即停止';button.style.cssText='padding:8px 16px;margin-top:10px;cursor:pointer';
      button.onclick=()=>{const id=job.id;stop();chrome.runtime.sendMessage({type:'LOCAL_STOP',id}).catch(()=>{});};box.append(status,button);shadow.append(box);panel.status=status;document.documentElement.append(panel);
    }
    const names={preparing:'正在查询目标',armed:'等待定时',running:'执行中',paused:'已暂停',stopped:'已停止',done:'已完成'};
    panel.status.textContent=`复旦研选 · ${names[job.status]}\n${job.logs.at(-1)?.message||''}`;
  }
  function report(){const s=snapshot();if(s)chrome.runtime.sendMessage({type:'REPORT',snapshot:s}).catch(()=>{if(job?.id===s.id&&!terminal(job.status))finish('paused','插件连接中断，请重新读取页面。',false);});}
  function log(message){job.logs.push({at:Date.now(),message});job.logs=job.logs.slice(-100);draw();report();}
  function finish(status,message,send=true){generation++;busy=false;clearTimeout(timer);job?.outcome?.close();if(!job)return;job.status=status;job.logs.push({at:Date.now(),message});job.logs=job.logs.slice(-100);draw();if(send)report();}
  function stop(){generation++;busy=false;if(job)finish('stopped','后续操作已停止，已发出的请求无法撤回。');}
  function guardFor(gen,deadline=false){return()=>{
    if(gen!==generation)throw Error('操作已取消。');
    if(document.visibilityState!=='visible')throw Error('选课页进入后台，已暂停。请保持页面前台。');
    if(deadline&&Date.now()>job.config.startAt+job.config.durationSec*1000)throw Error('等待窗口结束，请核对已选课程。');
  };}
  async function preflight(config){
    if(busy||(job&&!terminal(job.status)))throw Error('已有检查或任务运行，请先停止。');
    busy=true;const gen=++generation,guard=guardFor(gen),checks=[];
    try{for(const t of config.targets){const r=await A.navigate(t,guard);checks.push({name:t.fullName,category:C.categories[t.category].name,subcategory:t.subcategory,text:r.text,selected:r.selected,enabled:r.enabled});}return checks;}
    finally{if(gen===generation)busy=false;}
  }
  async function permit(kind,t,guard){guard();const r=await chrome.runtime.sendMessage({type:'PERMIT',id:job.id,kind,target:t.id});guard();if(!r?.ok)throw Error(r?.error||'任务授权失效。');}
  async function prepare(gen){
    const guard=guardFor(gen);
    try{
      for(const t of job.targets){guard();log(`正在定位：${C.categories[t.category].name} / ${t.subcategory||'全部'} / ${t.fullName}`);const r=await A.navigate(t,guard);if(r.selected)t.state='success';}
      const first=job.targets.find(t=>t.state!=='success');
      if(!first){finish('done','目标均已选，未提交任何请求。');return;}
      await A.navigate(first,guard);job.readyId=first.id;
      if(Date.now()>job.config.startAt)throw Error('准备查询完成时已错过开始时间，请设置更晚的时间。');
      job.status='armed';log('已完成分类查询，等待开始。请勿操作课程页面。');tick(gen);
    }catch(e){if(gen===generation)finish('paused',e.message);}
  }
  async function tick(gen){
    if(gen!==generation||!job||terminal(job.status))return;
    const c=job.config,guard=guardFor(gen,true);
    try{
      guard();const now=Date.now();
      if(Math.abs((now-job.wallStart)-(performance.now()-job.monoStart))>1000)throw Error('系统时间发生明显变化，请重新设置定时。');
      if(now<c.startAt){timer=setTimeout(()=>tick(gen),Math.min(1000,Math.max(10,(c.startAt-now)/2)));return;}
      if(job.status==='armed'){if(now-c.startAt>c.lateMs)throw Error(`迟到 ${now-c.startAt} 毫秒，停止补抢。`);job.status='running';log(`定时触发偏差 +${now-c.startAt} 毫秒。`);}
      const pending=job.targets.find(t=>t.state==='pending');
      if(pending){
        const result=job.outcome?.get();
        if(result==='failure')throw Error(`${pending.fullName}：网站提示选课失败，请查看弹窗。`);
        if(result==='success'){
          pending.state='success';job.outcome.close();job.outcome=null;job.readyId=null;log(`${pending.fullName}：本次提交后检测到网站“选课成功”提示，请最终核对已选课程。`);
        }else if(!pending.confirmed){
          const button=A.confirmation(pending);
          if(button){
            if(c.mode==='preview'){finish('paused',`${pending.fullName}：确认框匹配正确，试运行停止，未点击确定；请手动取消。`);return;}
            await permit('confirm',pending,guard);
            if(A.confirmation(pending)!==button)throw Error('确认框在提交前发生变化。');
            pending.confirmed=true;pending.confirmedAt=Date.now();job.outcome=A.freshOutcome();button.click();log(`${pending.fullName}：已点击最终确定，等待学校处理。`);
          }
        }
        if(Date.now()-(pending.confirmedAt||pending.clickedAt)>c.responseMs)throw Error(`${pending.fullName}：提交结果未确认，已暂停，绝不自动重复提交。`);
      }else{
        const unfinished=job.targets.filter(t=>!['success','simulated'].includes(t.state));
        const t=unfinished.find(t=>t.id===job.readyId) || unfinished.find(t=>Date.now()>=(t.nextAttempt||0));
        if(t){
          let r;
          if(job.readyId===t.id){if(!A.categoryActive(t))throw Error('你改变了课程分类，任务已暂停。');r=A.locate(t);}
          else {log(`查询目标：${t.fullName}`);r=await A.navigate(t,guard);}
          job.readyId=null;t.nextAttempt=Date.now()+c.intervalMs;
          if(r.selected){t.state='success';log(`${t.fullName}：已选，跳过。`);}
          else if(r.enabled){
            if(c.mode==='dry'){t.state='simulated';log(`演练：精确匹配 ${t.fullName}，不会点击选课或确定。`);}
            else{
              await permit('select',t,guard);A.assertNoDialog();const fresh=A.locate(t);
              if(!fresh.enabled)throw Error('选课按钮在操作前变为不可用。');
              t.state='pending';t.clickedAt=Date.now();fresh.button.click();log(`${t.fullName}：已点击选课，距计划时间 +${t.clickedAt-c.startAt} 毫秒。`);
            }
          }else{log(`${t.fullName}：已满或未开放，等待下一轮查询。`);}
        }
      }
      if(job.targets.every(t=>['success','simulated'].includes(t.state))){finish('done',c.mode==='dry'?'演练完成，没有提交选课。':'目标已处理，请最终核对学校课表。');return;}
      timer=setTimeout(()=>tick(gen),job.targets.some(t=>t.state==='pending')?200:c.intervalMs);
    }catch(e){if(gen===generation)finish('paused',e.message);}
  }
  function arm(id,config){
    if(busy||(job&&!terminal(job.status)))throw Error('已有任务，请先停止。');
    A.assertNoDialog();const gen=++generation;guardFor(gen)();
    job={id,config,status:'preparing',targets:config.targets.map(t=>({...t,state:'waiting'})),logs:[],wallStart:Date.now(),monoStart:performance.now(),outcome:null,readyId:null};
    log('正在逐门查询并验证完整课程名称与教学班。');prepare(gen);return snapshot();
  }
  // A fresh success message belongs to this task only while it owns the page.
  for(const type of ['pointerdown','keydown'])document.addEventListener(type,event=>{
    if(!event.isTrusted || event.composedPath().includes(panel))return;
    if(job&&!terminal(job.status))finish('paused','检测到你手动操作选课页面，已暂停；请核对结果后重新启动。');
    else if(busy){generation++;busy=false;}
  },true);
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState!=='visible'){if(job&&!terminal(job.status))finish('paused','选课页进入后台，已暂停。');else if(busy){generation++;busy=false;}}});
  addEventListener('pagehide',()=>{if(job&&!terminal(job.status))finish('paused','页面已刷新或离开，请重新启动。');else{generation++;busy=false;}});
  chrome.runtime.onMessage.addListener((m,s,reply)=>{
    if(m.type==='CHECK'){preflight(m.config).then(checks=>reply({ok:true,checks}),e=>reply({ok:false,error:e.message}));return true;}
    try{
      if(m.type==='ARM_PAGE')reply({ok:true,snapshot:arm(m.id,m.config)});
      else if(m.type==='STOP_PAGE'){stop();reply({ok:true});}
      else if(m.type==='STATUS_PAGE')reply({ok:true,snapshot:snapshot()});
    }catch(e){reply({ok:false,error:e.message});}
  });
  globalThis.FudanPage={preflight,arm,snapshot,stop};
})();
