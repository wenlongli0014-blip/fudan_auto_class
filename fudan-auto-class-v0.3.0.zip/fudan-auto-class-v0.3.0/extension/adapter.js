(() => {
  if(globalThis.FudanAdapter)return;
  const C=globalThis.FudanCore;
  const all=(root,s)=>[...root.querySelectorAll(s)];
  const visible=e=>!!e&&e.isConnected&&e.getClientRects().length>0&&getComputedStyle(e).visibility!=='hidden'&&getComputedStyle(e).display!=='none';
  const text=e=>C.norm(e?.innerText || e?.value || e?.textContent || '');
  const enabled=e=>visible(e)&&!e.disabled&&e.getAttribute('aria-disabled')!=='true'&&!e.closest('[inert]')&&!/(^|\s)(disabled|is-disabled)(\s|$)/.test(e.className||'');
  const one=(selector,root=document)=>{const a=all(root,selector).filter(visible);if(a.length!==1)throw Error(`页面结构不符：${selector} 应恰好匹配一个可见元素（实际 ${a.length}）。`);return a[0];};
  const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
  async function until(fn,guard,timeout=15000){const end=Date.now()+timeout;while(Date.now()<end){guard();const r=fn();if(r)return r;await delay(100);}throw Error('页面加载超时，请检查登录状态、课程分类和网络后重试。');}
  const dialogs=()=>all(document,'.zeromodal-container').filter(visible);
  function assertNoDialog(){if(dialogs().length)throw Error('页面存在弹窗，请手动取消或关闭后再继续。');}
  function rootFor(t){const cat=C.categories[t.category];return one('#xk_containrt_'+cat.container);}
  function rowName(row){
    const labels=all(row,'a').filter(visible).map(text).filter(s=>C.classIds(s).length===1);
    return [...new Set(labels.map(C.compact))];
  }
  function locate(t){
    const root=rootFor(t);
    const rows=all(root,'tbody tr').filter(visible).filter(r=>!all(r,'tr').length);
    const found=rows.filter(r=>rowName(r).includes(C.compact(t.fullName)));
    if(found.length!==1)throw Error(`${t.fullName}：完整“课程名称｜班级”匹配 ${found.length} 行，必须恰好一行。`);
    const row=found[0], buttons=all(row,'a[role="xk"]').filter(visible);
    const cells=all(row,'td').map(text);
    const selected=cells.some(s=>['已选','已选中','已选上'].includes(s)) || all(row,'a').some(e=>['退课','退选'].includes(text(e)));
    const unavailable=cells.some(s=>['已满','未开放','暂未开放'].includes(s));
    if(buttons.length>1 || (!buttons.length&&!selected&&!unavailable))throw Error(`${t.fullName}：选课按钮或状态未识别。`);
    const button=buttons[0];
    if(button && (text(button)!=='选课' || C.compact(button.getAttribute('role-kcms'))!==C.compact(t.fullName)))throw Error('选课按钮的课程身份与目标不符。');
    return {row,button,selected,unavailable,text:text(row),enabled:enabled(button)};
  }
  function categoryActive(t){
    const cat=C.categories[t.category], tab=document.querySelector('#xkkctab_'+cat.tab);
    if(!tab?.parentElement?.classList.contains('cv-active'))return false;
    if(cat.children.length){const sub=all(document,`#${cat.subContainer} .tab li`).filter(visible).filter(e=>text(e)===t.subcategory);return sub.length===1&&sub[0].classList.contains('activ');}
    return true;
  }
  function queryElements(t){const cat=C.categories[t.category];return {form:one('#'+cat.prefix+'QueryForm'),input:one('#'+cat.prefix+'_searchInput'),button:one('#'+cat.prefix+'_queryBtn')};}
  async function query(t,guard){
    assertNoDialog();guard();
    if(!categoryActive(t))throw Error('课程分类被改变，已停止操作。');
    const {form,input,button}=queryElements(t);
    // Website reads form values on its own query click. Set all values first;
    // dispatching change on each select would issue multiple university requests.
    for(const s of all(form,'select')){if([...s.options].some(o=>o.value===''))s.value='';}
    input.value=t.courseCode;input.dispatchEvent(new Event('input',{bubbles:true}));
    if(text(button)!=='查询'||!enabled(button))throw Error('查询按钮不可用。');
    const root=rootFor(t);let mutated=false,lastMutation=0;
    const observer=new MutationObserver(()=>{mutated=true;lastMutation=Date.now();});observer.observe(root,{subtree:true,childList:true,characterData:true});
    try{
      guard();button.click();
      await until(()=>mutated&&Date.now()-lastMutation>250&&!/正在加载|正在努力.*加载/.test(text(root)),guard);
      guard();if(!categoryActive(t))throw Error('查询期间分类已改变。');
      return locate(t);
    }finally{observer.disconnect();}
  }
  async function navigate(t,guard){
    guard();assertNoDialog();const cat=C.categories[t.category];
    const top=one('#xkkctab_'+cat.tab);
    if(text(top)!==cat.name)throw Error('网站课程大类名称与配置不符。');
    if(!top.parentElement.classList.contains('cv-active')){top.click();await until(()=>document.querySelector('#'+cat.prefix+'QueryForm')&&visible(document.querySelector('#'+cat.prefix+'QueryForm')),guard);}
    if(cat.children.length){
      const sub=await until(()=>all(document,`#${cat.subContainer} .tab li`).filter(visible).find(e=>text(e)===t.subcategory),guard);
      if(!sub.classList.contains('activ')){guard();sub.click();await until(()=>sub.classList.contains('activ')&&visible(document.querySelector('#'+cat.prefix+'QueryForm')),guard);}
    }
    // Let the category's initial request settle before issuing the targeted query.
    await until(()=>{const r=document.querySelector('#xk_containrt_'+cat.container);return visible(r)&&r.querySelector('tbody')&&!/正在加载|正在努力.*加载/.test(text(r));},guard);
    return query(t,guard);
  }
  function confirmation(t){
    const d=dialogs();
    const found=d.filter(e=>text(e).includes('当前选择的课程')&&C.classIds(text(e)).length===1&&C.classIds(text(e))[0]===t.classId&&C.compact(text(e)).includes(C.compact(t.fullName)));
    if(found.length>1)throw Error('存在多个课程确认框。');if(!found.length)return null;
    const buttons=all(found[0],'button, input[type="button"], a').filter(visible).filter(e=>text(e)==='确定');
    if(buttons.length!==1||!enabled(buttons[0]))throw Error('确认框的确定按钮不唯一或不可用。');
    if(d.length!==1)throw Error('页面有其他弹窗，请人工核对。');
    return buttons[0];
  }
  function freshOutcome(){
    let outcome=null;
    const check=node=>{if(!(node instanceof Element)||!visible(node))return;for(const e of [node,...node.querySelectorAll('*')]){if(!visible(e)||e.children.length)continue;const s=text(e);if(s==='选课成功！'||s==='选课成功!')outcome='success';if(s==='选课失败！'||s==='选课失败!')outcome='failure';}};
    const observer=new MutationObserver(records=>{for(const r of records){if(r.type==='characterData')check(r.target.parentElement);else for(const n of r.addedNodes)check(n.nodeType===3?n.parentElement:n);}});
    observer.observe(document.body,{childList:true,subtree:true,characterData:true});
    return {get:()=>outcome,close:()=>observer.disconnect()};
  }
  globalThis.FudanAdapter={visible,enabled,text,delay,until,locate,navigate,query,categoryActive,assertNoDialog,confirmation,freshOutcome};
})();
