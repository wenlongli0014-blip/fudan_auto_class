(() => {
  const norm = s => String(s ?? '').normalize('NFKC').replace(/\s+/g, ' ').trim();
  const compact = s => norm(s).replace(/[\s|｜]/g, '');
  const categories = {
    common: {name:'学位公共课',tab:'7',container:'7',prefix:'ggkc',subContainer:'ggkc_tab_container',children:['政治理论课','第一外国语','专业外语']},
    academic: {name:'学科专业课',tab:'8',container:'8',prefix:'xwzyk',subContainer:'xwzyk_tab_container',children:['学位基础课','学位专业课','专业选修课']},
    elective: {name:'公共选修课',tab:'9',container:'11',prefix:'ggxxk',children:[]},
    other: {name:'其他可选课程',tab:'10',container:'9',prefix:'qtkc',children:[]}
  };
  const defaults = {startAt:0,intervalMs:3000,durationSec:180,responseMs:90000,lateMs:5000,mode:'dry',targets:[]};
  function classIds(s) { return [...new Set((compact(s).match(/\d{10}[A-Z]{2,}\d{5}\.\d{2,}/g)||[]))]; }
  function parseCourse(fullName) {
    const s=compact(fullName), ids=classIds(s);
    if(ids.length!==1 || !s.endsWith(ids[0]) || s===ids[0]) throw Error('请粘贴完整“课程名称｜班级”，包含课程名和末尾的完整班级编号。');
    const classId=ids[0], courseName=s.slice(0,-classId.length), courseCode=classId.slice(10).split('.')[0];
    if(s.length>240)throw Error('课程名称过长。');
    return {fullName:norm(fullName),classId,courseName,courseCode};
  }
  function target(raw,index=0) {
    const cat=categories[raw.category];if(!cat)throw Error('请选择课程大类。');
    const subcategory=cat.children.length?raw.subcategory:'';
    if(cat.children.length && !cat.children.includes(subcategory))throw Error(`请选择${cat.name}的子类。`);
    return {id:String(index),category:raw.category,subcategory,...parseCourse(raw.fullName)};
  }
  function parseBeijing(value) {
    if(!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{1,3})?$/.test(value))throw Error('请输入包含秒的完整北京时间。');
    const ms=Date.parse(value+'+08:00');
    if(!Number.isFinite(ms)||new Date(ms+28800000).toISOString().slice(0,19)!==value.slice(0,19))throw Error('日期或时间无效。');
    return ms;
  }
  function validate(raw,now=Date.now(),schedule=true) {
    const c={...defaults,...raw};
    if(schedule&&(!Number.isFinite(c.startAt)||c.startAt<now+1000))throw Error('开始时间至少应在 1 秒之后，建议预留一分钟进行准备。');
    for(const [k,min,max] of [['intervalMs',3000,60000],['durationSec',10,1800],['responseMs',10000,180000],['lateMs',100,30000]])if(!Number.isInteger(c[k])||c[k]<min||c[k]>max)throw Error(`${k} 范围为 ${min}–${max}。`);
    if(!['dry','preview','live'].includes(c.mode))throw Error('运行模式无效。');
    if(!Array.isArray(c.targets)||!c.targets.length||c.targets.length>20)throw Error('请添加 1–20 门课程。');
    c.targets=c.targets.map(target);
    if(new Set(c.targets.map(t=>t.classId)).size!==c.targets.length)throw Error('同一教学班只能添加一次，即使它位于不同分类。');
    return c;
  }
  globalThis.FudanCore={norm,compact,categories,defaults,classIds,parseCourse,target,parseBeijing,validate};
})();
