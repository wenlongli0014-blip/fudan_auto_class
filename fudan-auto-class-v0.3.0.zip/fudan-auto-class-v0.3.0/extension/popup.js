const C=globalThis.FudanCore,$=id=>document.getElementById(id);
let ready=false,lastJob=null,connection=null;
const time=ms=>new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).format(new Date(ms));
const send=async m=>{const r=await chrome.runtime.sendMessage(m);if(!r?.ok)throw Error(r?.error||'插件未响应。');return r;};
function message(s,error=false){$('message').textContent=s;$('message').className=error?'error':'';}
function addTarget(t={category:'common',subcategory:'政治理论课',fullName:''}){
 const box=document.createElement('div');box.className='target';
 const title=document.createElement('div');title.className='target-head';const number=document.createElement('strong');number.textContent='目标课程';const remove=document.createElement('button');remove.textContent='删除';remove.onclick=()=>{box.remove();persist();};title.append(number,remove);
 const catLabel=document.createElement('label');catLabel.textContent='课程大类';const cat=document.createElement('select');cat.className='category';for(const [key,value]of Object.entries(C.categories)){const o=document.createElement('option');o.value=key;o.textContent=value.name;cat.append(o);}cat.value=t.category;catLabel.append(cat);
 const subLabel=document.createElement('label');subLabel.textContent='课程子类';const sub=document.createElement('select');sub.className='subcategory';subLabel.append(sub);
 function renderSub(){const children=C.categories[cat.value].children;sub.replaceChildren();for(const name of children){const o=document.createElement('option');o.value=name;o.textContent=name;sub.append(o);}subLabel.hidden=!children.length;}
 renderSub();if(t.subcategory)sub.value=t.subcategory;cat.onchange=()=>{renderSub();persist();$('preview').textContent='';};
 const fullLabel=document.createElement('label');fullLabel.textContent='课程名称｜班级（完整粘贴）';const full=document.createElement('textarea');full.className='fullName';full.placeholder='先进微纳加工2026202701PHYS30025.01';full.value=t.fullName;fullLabel.append(full);
 box.append(title,catLabel,subLabel,fullLabel);$('targets').append(box);
}
function draft(){return {schema:2,startValue:$('start').value,mode:$('mode').value,durationSec:Number($('duration').value),intervalMs:Number($('interval').value)*1000,lateMs:Number($('late').value),responseMs:Number($('response').value)*1000,targets:[...document.querySelectorAll('.target')].map(x=>({category:x.querySelector('.category').value,subcategory:x.querySelector('.subcategory').value,fullName:x.querySelector('.fullName').value}))};}
function config(schedule=true){const d=draft();return C.validate({...d,startAt:schedule?C.parseBeijing(d.startValue):0},Date.now(),schedule);}
async function persist(){if(ready)await chrome.storage.local.set({draft:draft()});}
function renderStatus(r){
 lastJob=r.job;connection=r.connection;const names={arming:'准备中',preparing:'查询目标中',armed:'等待定时',refreshing:'正在刷新',reloading:'页面加载中',resuming:'重新定位中',running:'执行中',paused:'已暂停',stopped:'已停止',done:'已完成'};
 $('connection').textContent=connection?'已连接选课标签页；定时刷新时会自动恢复连接。':'尚未连接';$('badge').textContent=names[lastJob?.status]||'未启动';
 const modes={dry:'只查询演练',preview:'弹窗试运行',live:'正式选课'};
 $('state').textContent=lastJob?`${names[lastJob.status]} · ${modes[lastJob.config.mode]}\n计划开始：${time(lastJob.config.startAt)}${lastJob.note?'\n'+lastJob.note:''}`:'尚无任务';$('state').style.whiteSpace='pre-wrap';
 $('logs').textContent=(lastJob?.snapshot?.logs||[]).map(l=>`[${time(l.at)}.${String(l.at%1000).padStart(3,'0')}] ${l.message}`).join('\n');
}
const refresh=async()=>renderStatus(await send({type:'STATUS'}));
function task(id,fn){$(id).onclick=async()=>{$(id).disabled=true;try{await fn();await persist();}catch(e){message(e.message,true);}finally{$(id).disabled=false;}};}
async function init(){
 const saved=(await chrome.storage.local.get('draft')).draft;const d={...C.defaults,...(saved?.schema===2?saved:{})};
 $('start').value=d.startValue||new Date(Date.now()+28800000+180000).toISOString().slice(0,23);$('mode').value=d.mode;$('duration').value=d.durationSec;$('interval').value=d.intervalMs/1000;$('late').value=d.lateMs;$('response').value=d.responseMs/1000;
 if(d.targets.length)d.targets.forEach(addTarget);else addTarget();ready=true;
 document.addEventListener('input',()=>{persist().catch(e=>message(e.message,true));$('preview').textContent='';});
 task('connect',async()=>{
  const granted=await chrome.permissions.request({origins:['http://yjsxk.fudan.edu.cn/*','https://yjsxk.fudan.edu.cn/*']});if(!granted)throw Error('需要选课网站访问权限。');
  const [tab]=await chrome.tabs.query({active:true,currentWindow:true});await send({type:'CONNECT',tabId:tab.id});message('已连接。请填写分类和完整课程名称。');await refresh();
 });
 task('add',async()=>addTarget());
 task('check',async()=>{const c=config(false);message('正在逐门切换分类并查询，请保持选课页面前台…');const r=await send({type:'CHECK',config:c});$('preview').textContent=r.checks.map((x,i)=>`${i+1}. ${x.category}${x.subcategory?' / '+x.subcategory:''}\n${x.name}\n${x.text}\n${x.selected?'已经选中':x.enabled?'可选，按钮身份已核对':'已满或未开放，可等待'}`).join('\n\n');message('所有目标均唯一匹配。请核对以上整行结果，查询没有提交选课。');});
 task('arm',async()=>{await send({type:'ARM',config:config()});message('任务已启动。到达时间后会先刷新选课页，再重新定位并执行。');await refresh();});
 task('stop',async()=>{await send({type:'STOP'});message('后续操作已停止。弹窗试运行后请手动点击学校弹窗的“取消”。');await refresh();});
 task('export',async()=>{if(!lastJob)throw Error('尚无任务日志。');const url=URL.createObjectURL(new Blob([JSON.stringify({version:'0.3.0',status:lastJob.status,note:lastJob.note,snapshot:lastJob.snapshot},null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='fudan-course-log.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),10000);});
 await refresh();setInterval(()=>{$('clock').textContent='当前北京时间：'+time(Date.now());refresh().catch(()=>{});},1000);
}
init().catch(e=>message(e.message,true));
