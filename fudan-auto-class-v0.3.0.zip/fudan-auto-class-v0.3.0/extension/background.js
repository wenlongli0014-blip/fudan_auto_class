importScripts('core.js');
const C=globalThis.FudanCore;
const originOK=url=>{try{const u=new URL(url);return ['http:','https:'].includes(u.protocol)&&u.hostname==='yjsxk.fudan.edu.cn';}catch{return false;}};
const active=j=>j&&['arming','preparing','armed','refreshing','reloading','resuming','running'].includes(j.status);
const getJob=async()=> (await chrome.storage.session.get('job')).job;
const save=async j=>{await chrome.storage.session.set({job:j});await chrome.action.setBadgeText({text:active(j)?'ON':j?.status==='paused'?'!':''});};
const page=(j,m)=>chrome.tabs.sendMessage(j.tabId,m,{documentId:j.documentId});
const inject=async tabId=>{
  const results=await chrome.scripting.executeScript({target:{tabId},files:['core.js','adapter.js','content.js']});
  const top=results.find(r=>r.frameId===0)||results[0];
  if(!top?.documentId)throw Error('无法绑定选课页面，请更新 Chrome。');
  return top.documentId;
};
let queue=Promise.resolve();
function serial(fn){const p=queue.then(fn);queue=p.catch(()=>{});return p;}
async function pause(id,note){
  await serial(async()=>{const j=await getJob();if(j?.id===id&&active(j)){j.status='paused';j.note=note;await save(j);}});
}
async function stop(reason='已停止'){
  const j=await serial(async()=>{const j=await getJob();if(j){j.status='stopped';j.note=reason;await save(j);}return j;});
  if(j)await page(j,{type:'STOP_PAGE'}).catch(()=>{});
  const {connection}=await chrome.storage.session.get('connection');if(connection&&connection.documentId!==j?.documentId)await page(connection,{type:'STOP_PAGE'}).catch(()=>{});
  return {ok:true};
}
async function resumeAfterReload(tabId,changeInfo,tab){
  if(changeInfo.status!=='complete')return;
  const pending=await serial(async()=>{
    const j=await getJob();if(!j||j.tabId!==tabId||j.status!=='reloading')return null;
    if(!originOK(tab.url)){j.status='paused';j.note='刷新后离开了选课网站，可能需要重新登录。';await save(j);return null;}
    j.status='resuming';j.note='页面刷新完成，正在恢复任务。';await save(j);return {id:j.id,tabId:j.tabId,config:j.config,snapshot:j.snapshot};
  });
  if(!pending)return;
  try{
    const documentId=await inject(tabId);
    const resumed=await serial(async()=>{
      const j=await getJob();if(j?.id!==pending.id||j.status!=='resuming')return null;
      j.documentId=documentId;await chrome.storage.session.set({connection:{tabId,documentId}});await save(j);return {...j};
    });
    if(!resumed)return;
    const r=await page(resumed,{type:'RESUME_PAGE',id:resumed.id,config:resumed.config,snapshot:pending.snapshot});
    if(!r?.ok)throw Error(r?.error||'刷新后任务恢复失败。');
  }catch(e){await pause(pending.id,`刷新后任务恢复失败：${e.message}`);}
}
async function handle(m,sender){
  if(sender.tab){
    if(!['REPORT','PERMIT','LOCAL_STOP','REFRESH'].includes(m.type)||!originOK(sender.url))throw Error('不接受该页面消息。');
    if(m.type==='LOCAL_STOP'){
      const j=await getJob();if(!j||j.id!==m.id||j.tabId!==sender.tab.id||j.documentId!==sender.documentId)throw Error('任务无效。');return stop('页面停止按钮');
    }
    if(m.type==='REFRESH'){
      const j=await serial(async()=>{
        const j=await getJob();if(!j||j.id!==m.id||j.tabId!==sender.tab.id||j.documentId!==sender.documentId)throw Error('任务已失效。');
        const now=Date.now();if(!['armed','refreshing'].includes(j.status)||now<j.config.startAt||now>j.config.startAt+j.config.lateMs)throw Error('不在允许刷新的定时触发范围。');
        j.status='reloading';j.note='到达开始时间，正在自动刷新选课页面。';if(m.snapshot?.id===j.id)j.snapshot=m.snapshot;await save(j);return {...j};
      });
      await chrome.tabs.reload(j.tabId);return {ok:true};
    }
    return serial(async()=>{
      const j=await getJob();if(!j||j.tabId!==sender.tab.id||j.documentId!==sender.documentId||(m.id||m.snapshot?.id)!==j.id)throw Error('任务已失效。');
      if(m.type==='REPORT'){
        if(active(j)&&['preparing','armed','refreshing','resuming','running','paused','stopped','done'].includes(m.snapshot.status)){j.status=m.snapshot.status;j.snapshot=m.snapshot;await save(j);}return {ok:true};
      }
      if(j.status!=='running')throw Error('任务尚未完成刷新和重新定位。');
      const now=Date.now();if(now<j.config.startAt||now>j.config.startAt+j.config.durationSec*1000)throw Error('不在执行时间窗口。');
      if(!j.config.targets.some(t=>t.id===m.target)||!['select','confirm'].includes(m.kind))throw Error('操作无效。');
      if(j.config.mode==='dry'||(m.kind==='confirm'&&j.config.mode!=='live'))throw Error('此模式不允许该点击。');
      const key=`${m.kind}:${m.target}`;if(j.sent.includes(key))throw Error('此操作已发出，不会重复提交。');
      if(m.kind==='confirm'&&!j.sent.includes(`select:${m.target}`))throw Error('尚未打开该课确认框。');
      j.sent.push(key);await save(j);return {ok:true};
    });
  }
  if(!sender.url?.startsWith(chrome.runtime.getURL('')))throw Error('仅允许插件界面操作。');
  if(m.type==='CONNECT'){
    const tab=await chrome.tabs.get(m.tabId);if(!originOK(tab.url))throw Error('请先打开并登录复旦研究生选课系统。');
    if(active(await getJob()))throw Error('已有任务运行，请先停止。');
    const documentId=await inject(m.tabId);const connection={tabId:m.tabId,documentId};await chrome.storage.session.set({connection});return {ok:true,connection};
  }
  if(m.type==='CHECK'||m.type==='ARM'){
    const config=C.validate(m.config,Date.now(),m.type==='ARM');
    const {connection}=await chrome.storage.session.get('connection');if(!connection)throw Error('请先连接选课页面。');
    const tab=await chrome.tabs.get(connection.tabId);if(!originOK(tab.url))throw Error('已离开选课网站，请重新连接。');
    if(m.type==='CHECK'){if(active(await getJob()))throw Error('请先停止正在运行的任务。');return page(connection,{type:'CHECK',config});}
    const j=await serial(async()=>{if(active(await getJob()))throw Error('已有任务运行，请先停止。');const j={...connection,id:crypto.randomUUID(),config,status:'arming',sent:[]};await save(j);return j;});
    try{
      const r=await page(j,{type:'ARM_PAGE',id:j.id,config});if(!r.ok)throw Error(r.error);
      return {ok:true,job:await getJob()};
    }catch(e){await pause(j.id,e.message);throw e;}
  }
  if(m.type==='STOP')return stop();
  if(m.type==='STATUS'){
    let j=await getJob();
    if(active(j)&&!['refreshing','reloading','resuming'].includes(j.status)){
      try{
        const r=await page(j,{type:'STATUS_PAGE'});if(r.snapshot?.id!==j.id)throw Error('执行环境丢失');
        await serial(async()=>{const latest=await getJob();if(latest?.id===j.id&&active(latest)){latest.snapshot=r.snapshot;latest.status=r.snapshot.status;await save(latest);}});
      }catch{await pause(j.id,'页面连接丢失，请重新启动。');}
      j=await getJob();
    }
    const {connection}=await chrome.storage.session.get('connection');return {ok:true,job:j||null,connection:connection||null};
  }
  throw Error('未知请求。');
}
chrome.runtime.onMessage.addListener((m,s,reply)=>{handle(m,s).then(reply,e=>reply({ok:false,error:e.message}));return true;});
chrome.tabs.onUpdated.addListener((tabId,changeInfo,tab)=>{resumeAfterReload(tabId,changeInfo,tab).catch(()=>{});});
chrome.tabs.onRemoved.addListener(tabId=>serial(async()=>{const j=await getJob();if(j?.tabId===tabId&&active(j)){j.status='stopped';j.note='标签页已关闭';await save(j);}}));
chrome.runtime.onInstalled.addListener(()=>stop('插件安装或更新，需重新启动任务。'));
