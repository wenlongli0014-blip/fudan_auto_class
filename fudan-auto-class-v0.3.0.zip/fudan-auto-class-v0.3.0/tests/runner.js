(async()=>{
 const out=document.getElementById('result');out.textContent='';
 const nativeLog=console.log;console.log=(...a)=>{nativeLog(...a);out.textContent+=a.join(' ')+'\n';};
 const browser={newPage:async()=>{
  const iframe=document.createElement('iframe');document.getElementById('stage').append(iframe);
  const evaluate=async(fn,arg)=>{iframe.contentWindow.__arg=arg;return await iframe.contentWindow.eval('('+fn.toString()+')(__arg)');};
  return {
   setContent:html=>new Promise(resolve=>{iframe.onload=resolve;iframe.srcdoc=html;}),
   evaluate,
   addScriptTag:async({content})=>{const s=iframe.contentDocument.createElement('script');s.textContent=content;iframe.contentDocument.head.append(s);},
   close:async()=>iframe.remove(),
   waitForTimeout:ms=>new Promise(r=>setTimeout(r,ms)),
   waitForFunction:async(fn,arg,options)=>{const end=Date.now()+options.timeout;while(Date.now()<end){if(await evaluate(fn,arg))return;await new Promise(r=>setTimeout(r,50));}throw Error('等待状态超时：'+arg);}
  };
 }};
 const assert={equal:(a,b)=>{if(a!==b)throw Error(`expected ${b}, got ${a}`);},ok:a=>{if(!a)throw Error('assertion failed');},deepEqual:(a,b)=>{if(JSON.stringify(a)!==JSON.stringify(b))throw Error('not equal');},match:(a,r)=>{if(!r.test(a))throw Error('pattern mismatch: '+a);},rejects:async(fn,r)=>{let error;try{await fn();}catch(e){error=e;}if(!error || !r.test(error.message))throw Error('expected rejection '+r+', got '+error);}};
 try{
  const [fixture,fixtureJs,core,adapter,content]=await Promise.all(['fixture.html','fixture.js','../extension/core.js','../extension/adapter.js','../extension/content.js'].map(p=>fetch(p).then(r=>r.text())));
  const count=await runFudanTests(browser,assert,{fixture,fixtureJs,core,adapter,content});out.dataset.result='passed';out.textContent+='全部通过：'+count+' 项';
 }catch(e){out.dataset.result='failed';out.textContent+='FAILED: '+e.stack;}
})();
