(() => {
 const C=FudanCore;
 const courses=[
  {category:'common',subcategory:'政治理论课',fullName:'高等统计2026202701MATH70001.01'},
  {category:'common',subcategory:'政治理论课',fullName:'高等统计2026202701MATH70001.02'},
  {category:'common',subcategory:'第一外国语',fullName:'学术英语2026202701GEEF40003.01'},
  {category:'academic',subcategory:'学位基础课',fullName:'算法分析2026202701COMP70002.01'},
  {category:'other',subcategory:'',fullName:'先进微纳加工2026202701PHYS30025.01'},
  {category:'elective',subcategory:'',fullName:'文学欣赏2026202701LITE70001.01'}
 ].map(t=>({...t,...C.parseCourse(t.fullName)}));
 window.fixture={courses,selected:[],clicks:[],queries:[],confirms:[],refreshes:[],mode:'success',full:new Set(),duplicate:false,wrongDialog:false,denied:false,latency:30};
 const listeners=[];window.chrome={runtime:{onMessage:{addListener:f=>listeners.push(f)},sendMessage:async m=>{
  if(m.type==='PERMIT'&&fixture.denied)return {ok:false,error:'任务已经停止'};
  if(m.type==='REFRESH'){
   fixture.refreshes.push({at:Date.now(),id:m.id});
   setTimeout(()=>FudanPage.resume(m.id,m.config,m.snapshot),0);
  }
  return {ok:true};
 }}};
 const nav=document.createElement('ul');nav.className='cv-tabs';document.querySelector('#xkTabContainer').append(nav);
 for(const [key,cat] of Object.entries(C.categories)){
  const li=document.createElement('li'),a=document.createElement('a');a.id='xkkctab_'+cat.tab;a.textContent=cat.name;a.href='#';li.append(a);nav.append(li);
  const container=document.createElement('section');container.id='xk_containrt_'+cat.container;container.className='cv-block-hide';document.querySelector('#containers').append(container);
  a.onclick=e=>{e.preventDefault();nav.querySelectorAll('li').forEach(l=>l.classList.remove('cv-active'));li.classList.add('cv-active');document.querySelectorAll('#containers>section').forEach(d=>d.classList.add('cv-block-hide'));container.classList.remove('cv-block-hide');mount(key,cat.children[0]||'');};
 }
 function mount(key,sub){
  const cat=C.categories[key],container=document.querySelector('#xk_containrt_'+cat.container);container.replaceChildren();
  if(cat.children.length){const div=document.createElement('div');div.id=cat.subContainer;const ul=document.createElement('ul');ul.className='tab';for(const name of cat.children){const li=document.createElement('li');li.textContent=name;li.className=name===sub?'activ':'';li.onclick=()=>mount(key,name);ul.append(li);}div.append(ul);container.append(div);}
  const form=document.createElement('form');form.id=cat.prefix+'QueryForm';form.onsubmit=e=>e.preventDefault();
  const input=document.createElement('input');input.id=cat.prefix+'_searchInput';const filter=document.createElement('select');filter.innerHTML='<option value="">...</option><option value="restricted" selected>旧院系限制</option>';
  const button=document.createElement('input');button.type='button';button.value='查询';button.id=cat.prefix+'_queryBtn';form.append(input,filter,button);container.append(form);
  const table=document.createElement('table');table.innerHTML='<thead><tr><th>课程代码</th><th>课程名称|班级</th><th>教师</th><th>容量</th><th>操作</th></tr></thead><tbody></tbody>';container.append(table);
  const render=()=>{
   const tbody=table.querySelector('tbody');tbody.replaceChildren();
   const data=courses.filter(c=>c.category===key&&c.subcategory===sub&&(!input.value||c.courseCode.includes(input.value)));
   if(fixture.duplicate&&data.length)data.push(data[0]);
   for(const c of data){const tr=document.createElement('tr');const td=document.createElement('td');td.textContent=c.courseCode;const name=document.createElement('td');const link=document.createElement('a');link.textContent=c.fullName;link.href='#';name.append(link);const teacher=document.createElement('td');teacher.textContent='测试教师';const capacity=document.createElement('td');capacity.textContent=fixture.full.has(c.classId)?'已满':'未满';const op=document.createElement('td');
    if(fixture.selected.includes(c.classId))op.textContent='已选';else if(fixture.full.has(c.classId))op.textContent='已满';else{const a=document.createElement('a');a.setAttribute('role','xk');a.setAttribute('role-kcms',c.fullName);a.textContent='选课';a.href='#';a.onclick=e=>{e.preventDefault();fixture.clicks.push({classId:c.classId,at:Date.now()});dialog(c,render);};op.append(a);}tr.append(td,name,teacher,capacity,op);tbody.append(tr);
   }
   if(!data.length)tbody.innerHTML='<tr><td colspan="5">本类别当前轮次无课程，请查看其他类别的课程！</td></tr>';
  };
  button.onclick=()=>{fixture.queries.push({category:key,subcategory:sub,code:input.value,filter:filter.value,at:Date.now()});table.querySelector('tbody').textContent='正在加载中';setTimeout(render,fixture.latency);};render();
 }
 function dialog(c,render){
  const d=document.createElement('div');d.className='zeromodal-container';const p=document.createElement('p');p.textContent='当前选择的课程：'+(fixture.wrongDialog?courses.find(x=>x.classId!==c.classId).fullName:c.fullName);const ok=document.createElement('button');ok.textContent='确定';const cancel=document.createElement('button');cancel.textContent='取消';cancel.onclick=()=>d.remove();
  ok.onclick=()=>{fixture.confirms.push(c.classId);d.remove();if(fixture.mode==='unknown')return;setTimeout(()=>{const tip=document.createElement('div');tip.textContent=fixture.mode==='failure'?'选课失败！':'选课成功！';document.body.append(tip);if(fixture.mode==='success'){fixture.selected.push(c.classId);render();}},30);};d.append(p,ok,cancel);document.body.append(d);
 }
 document.querySelector('#xkkctab_7').click();
})();
